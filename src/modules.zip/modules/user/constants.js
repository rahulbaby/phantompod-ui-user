//action Types
export const FETCH_ROWS = 'FETCH_CHILD_ROWS';

//API urls
export const FETCH_ROWS_API = 'student';

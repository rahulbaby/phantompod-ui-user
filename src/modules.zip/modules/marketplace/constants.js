//action Types
export const REFRESH_ROWS = 'pod/REFRESH_ROWS';
export const SET_LOADING = 'pod/SET_LOADING';
export const SET_PAGE = 'pod/SET_PAGE';
export const RESET_STORE = 'pod/RESET_STORE';

//API urls
export const FETCH_ROWS_API = 'pod/marketplace';

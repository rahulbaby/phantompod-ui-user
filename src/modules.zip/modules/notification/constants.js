//action Types
export const FETCH_ROWS = 'FETCH_NOTIFICATION_ROWS';

//API urls
export const FETCH_ROWS_API = 'notification';

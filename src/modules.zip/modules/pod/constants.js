//action Types
export const FETCH_ROWS = 'FETCH_POD_ROWS';
export const REFRESH_ROWS = 'pod/REFRESH_ROWS_ROWS';
export const REMOVE_ROW = 'pod/REMOVE_ROW';
export const ADD_ROW = 'pod/ADD_ROW';

//API urls
export const FETCH_ROWS_API = 'pod';

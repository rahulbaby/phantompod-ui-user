//action Types
export const REFRESH_ROWS = 'post/REFRESH_ROWS';
export const SET_LOADING = 'post/SET_LOADING';
export const SET_PAGE = 'post/SET_PAGE';
export const RESET_STORE = 'post/RESET_STORE';

//API urls
export const FETCH_ROWS_API = 'post';
